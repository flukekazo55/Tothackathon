Avenxo
(c) 2015

http://themeforest.net/user/KaijuThemes
http://kaijuthemes.com
---------------------------------------

Folder structure


- admin - contains the HTML demo files
- admin/angular - contains the AngularJS demo files

- docs/html - contains the documentation for the HTML version
- docs/angular - contains the documentatation for the AngularJS version

- psd - PSD file with all it's primary elements are provided in it's own directory


Thank you for purchasing this theme. We put a lot of work behind it, and would appreciate you rating this theme highly in themeforest. If you have any issues with the theme, please let us know first.

For any questions, comments, or suggestions of improvements, please leave a comment at our TF page or send us an email at themes@kaijuthemes.com


- KaijuThemes